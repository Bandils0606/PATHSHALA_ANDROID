package com.example.paathshala;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;


public class website extends AppCompatActivity{

        ImageButton jtplogo, gfglogo, w3slogo;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_website);
            jtplogo=(ImageButton) findViewById(R.id.jtplogo);
            gfglogo=(ImageButton) findViewById(R.id.gfglogo);
            w3slogo=(ImageButton) findViewById(R.id.w3slogo);


            jtplogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(website.this, javatpoint.class);
                    startActivity(intent);
                }
            });

            gfglogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(website.this, geeksforgeeks.class);
                    startActivity(intent);
                }
            });

            w3slogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(website.this, w3schools.class);
                    startActivity(intent);
                }
            });


        }
    }

