package com.example.paathshala;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class geeksforgeeks extends AppCompatActivity {
    ImageButton g_c, g_cpp, g_ml, g_java, g_python;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.geeksforgeeks);

        g_c=(ImageButton) findViewById(R.id.g_c);
        g_cpp=(ImageButton) findViewById(R.id.g_cpp);
        g_ml=(ImageButton) findViewById(R.id.g_ml);
        g_java=(ImageButton) findViewById(R.id.g_java);
        g_python=(ImageButton) findViewById(R.id.g_python);

        g_c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.geeksforgeeks.org/c-programming-language/?ref=leftbar");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        g_cpp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.geeksforgeeks.org/c-plus-plus/?ref=leftbar");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        g_ml.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.geeksforgeeks.org/machine-learning/");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        g_java.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.geeksforgeeks.org/java/?ref=leftbar");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        g_python.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.geeksforgeeks.org/python-programming-language/?ref=leftbar");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
    }
}